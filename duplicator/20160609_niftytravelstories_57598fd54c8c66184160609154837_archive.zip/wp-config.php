<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'student203i');

/** MySQL database username */
define('DB_USER', 'student203');

/** MySQL database password */
define('DB_PASSWORD', 'student203');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '}-1c*f:*;~K.o}W]U7w#+6d:ZKpRFCy+]+Yn(S=j/gAcssW(0-r(Bo%xtJbQ;h,?');
define('SECURE_AUTH_KEY',  'S5;r+H?BFrhq18DGC=Yhgm;FAS$!Vu#pWf#HG|gyI;T:_o$or|5][$Y*4pi>aV$1');
define('LOGGED_IN_KEY',    'BU&1#VQQ/HC&hX[#xz<.3!!tRsSXczyo#q6DN%4QzVIy+JRn*7NX%v!n.XTg^Ju#');
define('NONCE_KEY',        '!$K2; v>_0Eb%K|IC1tmcB`7Kxh(-1_B5}dHuvn,j@9?s%8923.ZV ts5(sc~/$G');
define('AUTH_SALT',        '>DjIaG1xF2jTLI|Va&g3R/Sh*i3h#|6S&_D0BNX6X|[Yx2~`@:|=Nn^|d~$>882L');
define('SECURE_AUTH_SALT', '~F|[E[T:~$-WSD:p2snD%M;.)Ok$!,5!2V}@O5d!%Fb|,Z<|w?pHENQ07:}Vbn,?');
define('LOGGED_IN_SALT',   '-nrOiP.rp[fo-] ?d6RWvj&+z47+|-Sid!?A`w,hB]+*N_bBWL1:7`xv=Wnl?sqo');
define('NONCE_SALT',       ']0[|59wyEZ36HiE!|C}@51C.e5/-oj7yGsEm2x7nB+f/?_FyyE;)M@~F>Hh,L`4b');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
